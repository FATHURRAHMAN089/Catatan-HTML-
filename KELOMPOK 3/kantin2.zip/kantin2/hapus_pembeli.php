<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db = "kantin_sekolah1";
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Hapus Pembeli Berdasarkan ID
$id_pembeli = $_GET['id'];
$conn->query("DELETE FROM pembeli WHERE id_pembeli='$id_pembeli'");

header("Location: pembeli.php");
exit();
?>
