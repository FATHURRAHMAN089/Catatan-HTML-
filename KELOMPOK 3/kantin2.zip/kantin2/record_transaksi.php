<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db = "kantin_sekolah1";
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil ID Pembeli
$id_pembeli = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Debugging: Pastikan ID Pembeli dikirim dengan benar
if ($id_pembeli == 0) {
    die("ID Pembeli tidak valid!");
}

// Ambil data pembeli
$pembeli_result = $conn->query("SELECT * FROM pembeli WHERE id_pembeli = $id_pembeli");

if ($pembeli_result->num_rows == 0) {
    die("Pembeli tidak ditemukan!");
}

$pembeli = $pembeli_result->fetch_assoc();

// Ambil total harga transaksi berdasarkan id_pembeli
$transaksi_query = "SELECT SUM(total_harga) as total_bayar FROM transaksi WHERE id_pembeli = $id_pembeli";
$transaksi_result = $conn->query($transaksi_query);

// Debugging: Tampilkan query jika ada masalah
if (!$transaksi_result) {
    die("Error pada query: " . $conn->error);
}

$transaksi = $transaksi_result->fetch_assoc();
$total_bayar = $transaksi['total_bayar'] ?? 0; // Jika NULL, maka set 0

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Record Pembeli</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">Kantin Sekolah</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="produk.php">Produk</a></li>
                <li class="nav-item"><a class="nav-link" href="transaksi.php">Transaksi</a></li>
                <li class="nav-item"><a class="nav-link active" href="pembeli.php">Pembeli</a></li>
                <li class="nav-item"><a class="nav-link" href="pegawai.php">Pegawai</a></li>
                <li class="nav-item"><a class="btn btn-danger" href="login.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <h3>Record Total Pembayaran Pembeli: <?= htmlspecialchars($pembeli['nama_pembeli']); ?></h3>
    <a href="pembeli.php" class="btn btn-secondary mb-3">Kembali</a>

    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Total yang telah dibayarkan:</h5>
            <p class="card-text fs-4 fw-bold text-primary">
                Rp <?= number_format($total_bayar, 0, ',', '.'); ?>
            </p>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
