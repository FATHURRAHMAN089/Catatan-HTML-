<?php
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_produk = $_POST['nama_produk'];
    $jenis_produk = $_POST['jenis_produk'];
    $harga_produk = $_POST['harga_produk'];

    $query = "INSERT INTO produk (nama_produk, jenis_produk, harga_produk) VALUES ('$nama_produk', '$jenis_produk', '$harga_produk')";
    $conn->query($query);

    header("Location: produk.php");
    exit;
}

// Mengambil daftar jenis produk yang sudah ada
$kategori_result = $conn->query("SELECT DISTINCT jenis_produk FROM produk");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk - Kantin Sekolah</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }
        .btn {
            transition: 0.3s ease-in-out;
        }
        .btn:hover {
            opacity: 0.8;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Kantin Sekolah</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link active" href="produk.php">Produk</a></li>
                    <li class="nav-item"><a class="nav-link" href="transaksi.php">Transaksi</a></li>
                    <li class="nav-item"><a class="nav-link" href="pembeli.php">Pembeli</a></li>
                    <li class="nav-item"><a class="nav-link" href="pegawai.php">Pegawai</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h2>Tambah Produk Baru</h2>
                    <a href="produk.php" class="btn btn-secondary">Kembali ke Daftar Produk</a>
                </div>
                
                <div class="form-container">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Nama Produk</label>
                            <input type="text" name="nama_produk" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Jenis Produk</label>
                            <select name="jenis_produk" class="form-control" required>
                                <?php while ($kategori = $kategori_result->fetch_assoc()) { ?>
                                    <option value="<?= $kategori['jenis_produk']; ?>"><?= $kategori['jenis_produk']; ?></option>
                                <?php } ?>
                                <option value="Lainnya">Lainnya</option>
                            </select>
                        </div>
                        <div class="mb-3" id="jenis_baru_container" style="display: none;">
                            <label class="form-label">Jenis Produk Baru</label>
                            <input type="text" id="jenis_produk_baru" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Harga Produk</label>
                            <div class="input-group">
                                <span class="input-group-text">Rp</span>
                                <input type="number" name="harga_produk" class="form-control" required>
                            </div>
                        </div>
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Simpan Produk</button>
                            <a href="produk.php" class="btn btn-outline-secondary">Batal</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Script untuk menampilkan input jenis produk baru jika "Lainnya" dipilih
        document.querySelector('select[name="jenis_produk"]').addEventListener('change', function() {
            const jenisBaru = document.getElementById('jenis_baru_container');
            if (this.value === 'Lainnya') {
                jenisBaru.style.display = 'block';
                document.getElementById('jenis_produk_baru').setAttribute('name', 'jenis_produk');
                this.removeAttribute('name');
            } else {
                jenisBaru.style.display = 'none';
                document.getElementById('jenis_produk_baru').removeAttribute('name');
                this.setAttribute('name', 'jenis_produk');
            }
        });
    </script>
</body>
</html>