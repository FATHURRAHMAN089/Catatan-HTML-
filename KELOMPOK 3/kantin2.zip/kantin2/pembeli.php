<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db = "kantin_sekolah1";
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil Data Pembeli dan jumlah transaksi
$pembeli_result = $conn->query("SELECT p.*, COUNT(t.id_transaksi) as jumlah_transaksi 
                                FROM pembeli p 
                                LEFT JOIN transaksi t ON p.id_pembeli = t.id_pembeli 
                                GROUP BY p.id_pembeli");

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Pembeli</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">Kantin Sekolah</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="produk.php">Produk</a></li>
                <li class="nav-item"><a class="nav-link" href="transaksi.php">Transaksi</a></li>
                <li class="nav-item"><a class="nav-link active" href="pembeli.php">Pembeli</a></li>
                <li class="nav-item"><a class="nav-link" href="pegawai.php">Pegawai</a></li>
                <li class="nav-item"><a class="btn btn-danger" href="login.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <h3 class="mb-3 text-center">Data Pembeli</h3>

    <a href="tambah_pembeli.php" class="btn btn-primary mb-3">
        <i class="bi bi-person-plus"></i> Tambah Pembeli
    </a>

    <div class="table-responsive">
        <table class="table table-striped table-hover table-bordered rounded-3 shadow">
            <thead class="table-dark">
                <tr class="text-center">
                    <th style="width: 10%;">No</th>
                    <th style="width: 50%;">Nama Pembeli</th>
                    <th style="width: 20%;">Jumlah Transaksi</th>
                    <th style="width: 20%;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; while ($pembeli = $pembeli_result->fetch_assoc()) { ?>
                    <tr class="align-middle">
                        <td class="text-center"><?= $no++; ?></td>
                        <td><?= htmlspecialchars($pembeli['nama_pembeli']); ?></td>
                        <td class="text-center"><?= $pembeli['jumlah_transaksi']; ?> kali</td>
                        <td class="text-center">
                            <a href="edit_pembeli.php?id=<?= $pembeli['id_pembeli']; ?>" class="btn btn-warning btn-sm">
                                <i class="bi bi-pencil-square"></i> Edit
                            </a>
                            <a href="hapus_pembeli.php?id=<?= $pembeli['id_pembeli']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus pembeli ini?');">
                                <i class="bi bi-trash"></i> Hapus
                            </a>
                            <a href="record_transaksi.php?id=<?= $pembeli['id_pembeli']; ?>" class="btn btn-info btn-sm">
                                <i class="bi bi-receipt"></i> Record
                            </a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
