<?php
include 'koneksi.php';

// Mengambil produk unggulan
$produk_unggulan = $conn->query("SELECT * FROM produk ORDER BY RAND() LIMIT 6");

// Mengambil kategori produk
$kategori = $conn->query("SELECT DISTINCT jenis_produk FROM produk");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kantin Sekolah - Selamat Datang</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Poppins', sans-serif;
        }
        
        .hero-section {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('/api/placeholder/1200/500');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 100px 0;
            margin-bottom: 30px;
        }
        
        .product-card {
            transition: transform 0.3s;
            border: none;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            overflow: hidden;
        }
        
        .product-card:hover {
            transform: translateY(-5px);
        }
        
        .product-image {
            height: 200px;
            object-fit: cover;
        }
        
        .category-card {
            position: relative;
            overflow: hidden;
            border-radius: 10px;
            cursor: pointer;
            margin-bottom: 20px;
        }
        
        .category-img {
            width: 100%;
            height: 150px;
            object-fit: cover;
            transition: transform 0.3s;
        }
        
        .category-card:hover .category-img {
            transform: scale(1.1);
        }
        
        .category-overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background: linear-gradient(transparent, rgba(0, 0, 0, 0.7));
            padding: 15px;
            color: white;
        }
        
        .section-title {
            position: relative;
            margin-bottom: 30px;
            padding-bottom: 15px;
        }
        
        .section-title:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 60px;
            height: 3px;
            background-color: #0d6efd;
        }
        
        .nav-link {
            font-weight: 500;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.5rem;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Kantin Sekolah</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link btn btn-primary ms-lg-3 text-white" href="login.php">Login</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="hero-section">
        <div class="container text-center">
            <h1 class="display-4 fw-bold mb-4">Selamat Datang di Kantin Sekolah</h1>
            <p class="lead mb-4">Nikmati makanan lezat dan beragam kebutuhan sekolah di satu tempat</p>
        </div>
    </div>


    <div class="container mb-5">
        <h2 class="section-title">Produk Unggulan</h2>
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card product-card h-100">
                    <img src="nasgor.jpg" class="card-img-top product-image" alt="Nasi Goreng">
                    <div class="card-body">
                        <h5 class="card-title">Nasi Goreng Spesial</h5>
                        <p class="card-text text-muted">Makanan</p>
                        <p class="card-text fw-bold text-primary">Rp 15.000</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card product-card h-100">
                    <img src="es.jpg" class="card-img-top product-image" alt="Es Teh">
                    <div class="card-body">
                        <h5 class="card-title">Es Teh Manis</h5>
                        <p class="card-text text-muted">Minuman</p>
                        <p class="card-text fw-bold text-primary">Rp 5.000</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card product-card h-100">
                    <img src="pulpen.jpg" class="card-img-top product-image" alt="Pulpen">
                    <div class="card-body">
                        <h5 class="card-title">Pulpen Standard</h5>
                        <p class="card-text text-muted">Alat Tulis</p>
                        <p class="card-text fw-bold text-primary">Rp 3.000</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
