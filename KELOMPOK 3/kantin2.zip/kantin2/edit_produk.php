<?php
include 'koneksi.php';

$id = $_GET['id'];
$result = $conn->query("SELECT * FROM produk WHERE id_produk = $id");
$data = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_produk = $_POST['nama_produk'];
    $jenis_produk = $_POST['jenis_produk'];
    $harga_produk = $_POST['harga_produk'];

    $query = "UPDATE produk SET nama_produk='$nama_produk', jenis_produk='$jenis_produk', harga_produk='$harga_produk' WHERE id_produk=$id";
    $conn->query($query);

    header("Location: produk.php");
    exit;
}

$kategori_result = $conn->query("SELECT DISTINCT jenis_produk FROM produk");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h2>Edit Produk</h2>
        <form method="POST">
            <div class="mb-3">
                <label>Nama Produk</label>
                <input type="text" name="nama_produk" class="form-control" value="<?= $data['nama_produk']; ?>" required>
            </div>
            <div class="mb-3">
                <label>Jenis Produk</label>
                <select name="jenis_produk" class="form-control" required>
                    <?php while ($kategori = $kategori_result->fetch_assoc()) { ?>
                        <option value="<?= $kategori['jenis_produk']; ?>" <?= ($kategori['jenis_produk'] == $data['jenis_produk']) ? 'selected' : ''; ?>>
                            <?= $kategori['jenis_produk']; ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
            <div class="mb-3">
                <label>Harga Produk</label>
                <input type="number" name="harga_produk" class="form-control" value="<?= $data['harga_produk']; ?>" required>
            </div>
            <button type="submit" class="btn btn-success">Simpan</button>
            <a href="produk.php" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</body>
</html>
