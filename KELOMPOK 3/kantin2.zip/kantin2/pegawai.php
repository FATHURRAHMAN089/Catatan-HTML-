<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db = "kantin_sekolah1";
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Tambah Pegawai
if (isset($_POST['tambah'])) {
    $nama_pegawai = $_POST['nama_pegawai'];

    $query = "INSERT INTO pegawai_kantin (nama_pegawai) VALUES ('$nama_pegawai')";
    $conn->query($query);
    header("Location: pegawai.php");
    exit();
}

// Hapus Pegawai
if (isset($_GET['hapus'])) {
    $id_pegawai = $_GET['hapus'];
    $conn->query("DELETE FROM pegawai_kantin WHERE id_pegawai = '$id_pegawai'");
    header("Location: pegawai.php");
    exit();
}

// Ambil Data Pegawai
$pegawai_result = $conn->query("SELECT * FROM pegawai_kantin");

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Pegawai Kantin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">Kantin Sekolah</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="produk.php">Produk</a></li>
                <li class="nav-item"><a class="nav-link" href="transaksi.php">Transaksi</a></li>
                <li class="nav-item"><a class="nav-link" href="pembeli.php">Pembeli</a></li>
                <li class="nav-item"><a class="nav-link active" href="pegawai.php">Pegawai</a></li>
                <li class="nav-item"><a class="btn btn-danger" href="login.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <h3 class="mb-3 text-center">Data Pegawai Kantin</h3>

    <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#tambahModal">
        <i class="bi bi-plus-circle"></i> Tambah Pegawai
    </button>

    <div class="table-responsive">
        <table class="table table-striped table-hover table-bordered rounded-3 shadow">
            <thead class="table-dark">
                <tr class="text-center">
                    <th style="width: 10%;">No</th>
                    <th style="width: 60%;">Nama Pegawai</th>
                    <th style="width: 30%;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; while ($pegawai = $pegawai_result->fetch_assoc()) { ?>
                    <tr class="align-middle">
                        <td class="text-center"><?= $no++; ?></td>
                        <td><?= htmlspecialchars($pegawai['nama_pegawai']); ?></td>
                        <td class="text-center">
                            <a href="edit_pegawai.php?id=<?= $pegawai['id_pegawai']; ?>" class="btn btn-warning btn-sm">
                                <i class="bi bi-pencil-square"></i> Edit
                            </a>
                            <a href="pegawai.php?hapus=<?= $pegawai['id_pegawai']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus pegawai ini?');">
                                <i class="bi bi-trash"></i> Hapus
                            </a>
                            <a href="record.php?id=<?= $pegawai['id_pegawai']; ?>" class="btn btn-info btn-sm">
                                <i class="bi bi-file-earmark-text"></i> Record
                            </a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Tambah Pegawai -->
<div class="modal fade" id="tambahModal" tabindex="-1" aria-labelledby="tambahModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tambahModalLabel">Tambah Pegawai</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Nama Pegawai</label>
                        <input type="text" name="nama_pegawai" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="tambah" class="btn btn-primary">Tambah</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
