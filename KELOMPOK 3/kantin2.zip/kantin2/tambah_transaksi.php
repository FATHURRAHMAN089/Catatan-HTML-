<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db = "kantin_sekolah1";
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Handler untuk request AJAX total harga
if (isset($_GET['action']) && $_GET['action'] == 'get_total') {
    $id_produk = $_GET['id_produk'];
    $total_produk = $_GET['total_produk'];
    
    // Gunakan SQL agregasi untuk menghitung total harga
    $query = "SELECT SUM(harga_produk * $total_produk) AS total_harga 
              FROM produk WHERE id_produk = '$id_produk'";
    $result = $conn->query($query);
    $data = $result->fetch_assoc();
    
    // Kirim response sebagai JSON
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

// Handler untuk request AJAX kembalian
if (isset($_GET['action']) && $_GET['action'] == 'get_kembalian') {
    $id_produk = $_GET['id_produk'];
    $total_produk = $_GET['total_produk'];
    $total_bayar = $_GET['total_bayar'];
    
    // Gunakan SQL agregasi untuk menghitung kembalian
    $query = "SELECT ($total_bayar - SUM(harga_produk * $total_produk)) AS kembalian 
              FROM produk WHERE id_produk = '$id_produk'";
    $result = $conn->query($query);
    $data = $result->fetch_assoc();
    
    // Kirim response sebagai JSON
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

// Ambil data produk, pembeli, dan pegawai
$produk_result = $conn->query("SELECT * FROM produk");
$pembeli_result = $conn->query("SELECT * FROM pembeli");
$pegawai_result = $conn->query("SELECT * FROM pegawai_kantin");

// Tambah transaksi
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_pembeli = $_POST['id_pembeli'];
    $id_produk = $_POST['id_produk'];
    $id_pegawai = $_POST['id_pegawai'];
    $total_produk = $_POST['total_produk'];
    $total_bayar = $_POST['total_bayar'];
    
    // Ambil waktu saat ini
    $waktu_beli = date('Y-m-d H:i:s');

    // Gunakan SQL untuk mengambil harga dan menghitung total secara agregasi
    $total_query = $conn->query("SELECT SUM(harga_produk * $total_produk) AS total_harga 
                               FROM produk WHERE id_produk = '$id_produk'");
    $total_result = $total_query->fetch_assoc();
    $total_harga = $total_result['total_harga'];
    
    // Hitung kembalian dengan agregasi
    $kembalian_query = $conn->query("SELECT ($total_bayar - SUM(harga_produk * $total_produk)) AS kembalian 
                                   FROM produk WHERE id_produk = '$id_produk'");
    $kembalian_result = $kembalian_query->fetch_assoc();
    $kembalian = $kembalian_result['kembalian'];

    // Masukkan transaksi ke database dengan waktu_beli
    $query = "INSERT INTO transaksi (id_pembeli, id_produk, id_pegawai, waktu_beli, total_produk, total_harga, total_bayar, kembalian) 
              VALUES ('$id_pembeli', '$id_produk', '$id_pegawai', '$waktu_beli', '$total_produk', '$total_harga', '$total_bayar', '$kembalian')";

    if ($conn->query($query) === TRUE) {
        header("Location: transaksi.php");
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Transaksi - Kantin Sekolah</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script>
        function updateTotal() {
            const produkSelect = document.getElementById("id_produk");
            const idProduk = produkSelect.value;
            const totalProduk = document.getElementById("total_produk").value;
            
            if (totalProduk > 0) {
                // Gunakan fetch API untuk mendapatkan total harga melalui agregasi dari server
                fetch(`tambah_transaksi.php?action=get_total&id_produk=${idProduk}&total_produk=${totalProduk}`)
                    .then(response => response.json())
                    .then(data => {
                        document.getElementById("total_harga").value = data.total_harga;
                        document.getElementById("total_harga_display").innerText = "Rp " + 
                            parseInt(data.total_harga).toLocaleString('id-ID');
                        hitungKembalian();
                    });
            }
        }

        function hitungKembalian() {
            const totalProduk = document.getElementById("total_produk").value;
            const idProduk = document.getElementById("id_produk").value;
            const totalBayar = document.getElementById("total_bayar").value;
            
            if (totalProduk > 0 && totalBayar > 0) {
                // Gunakan fetch API untuk mendapatkan kembalian melalui agregasi dari server
                fetch(`tambah_transaksi.php?action=get_kembalian&id_produk=${idProduk}&total_produk=${totalProduk}&total_bayar=${totalBayar}`)
                    .then(response => response.json())
                    .then(data => {
                        document.getElementById("kembalian").value = data.kembalian;
                        document.getElementById("kembalian_display").innerText = "Rp " + 
                            parseInt(data.kembalian).toLocaleString('id-ID');
                    });
            }
        }
    </script>
    <style>
        /* Main Styling for Kantin Sekolah App */
:root {
  --primary-color: #3a7bd5;
  --primary-dark: #2b5da0;
  --secondary-color: #f4f7fc;
  --success-color: #28a745;
  --warning-color: #ffc107;
  --danger-color: #dc3545;
  --light-gray: #f8f9fa;
  --dark-gray: #343a40;
  --text-color: #212529;
  --border-radius: 0.5rem;
  --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  --transition: all 0.3s ease;
}

body {
  font-family: 'Poppins', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
  background-color: #f5f7fa;
  color: var(--text-color);
  line-height: 1.6;
}

/* Navbar Styling - Keeping it close to original */
.navbar {
  padding: 0.5rem 1rem;
  background-color: #343a40 !important;
}

.navbar-brand {
  font-weight: 600;
  color: white !important;
}

.navbar-dark .navbar-nav .nav-link {
  color: rgba(255, 255, 255, 0.85);
  padding: 0.5rem 1rem;
  transition: color 0.15s ease-in-out;
}

.navbar-dark .navbar-nav .nav-link:hover {
  color: white;
}

/* Container Styling */
.container {
  max-width: 1200px;
  padding: 0 1.5rem;
}

/* Card Styling */
.card {
  border: none;
  border-radius: var(--border-radius);
  box-shadow: var(--box-shadow);
  transition: var(--transition);
  background-color: white;
}

.card:hover {
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
}

/* Form Styling */
.form-label {
  font-weight: 600;
  margin-bottom: 0.5rem;
  color: var(--dark-gray);
}

.form-control {
  border-radius: var(--border-radius);
  padding: 0.75rem 1rem;
  border: 1px solid #dee2e6;
  transition: var(--transition);
}

.form-control:focus {
  box-shadow: 0 0 0 0.2rem rgba(58, 123, 213, 0.25);
  border-color: var(--primary-color);
}

.form-control-static {
  background-color: var(--secondary-color);
  padding: 0.75rem 1rem;
  border-radius: var(--border-radius);
  font-weight: 600;
  color: var(--primary-dark);
}

select.form-control {
  cursor: pointer;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16'%3E%3Cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 1rem center;
  background-size: 16px 12px;
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;
}

/* Button Styling */
.btn {
  padding: 0.75rem 1.5rem;
  font-weight: 600;
  border-radius: var(--border-radius);
  transition: var(--transition);
}

.btn-primary {
  background-color: var(--primary-color);
  border-color: var(--primary-color);
}

.btn-primary:hover {
  background-color: var(--primary-dark);
  border-color: var(--primary-dark);
  transform: translateY(-2px);
}

.btn-secondary {
  background-color: var(--dark-gray);
  border-color: var(--dark-gray);
}

.btn-secondary:hover {
  background-color: #23272b;
  border-color: #23272b;
  transform: translateY(-2px);
}

.btn-outline-secondary {
  color: var(--dark-gray);
  border-color: var(--dark-gray);
}

.btn-outline-secondary:hover {
  background-color: var(--dark-gray);
  color: white;
  transform: translateY(-2px);
}

/* Page Header */
.d-flex.justify-content-between.align-items-center {
  margin-bottom: 2rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid rgba(0, 0, 0, 0.08);
}

.d-flex h3 {
  font-weight: 700;
  color: var(--dark-gray);
  font-size: 1.75rem;
}

/* Responsive Styles */
@media (max-width: 992px) {
  .d-flex.justify-content-between.align-items-center {
    flex-direction: column;
    align-items: flex-start !important;
  }
  
  .d-flex h3 {
    margin-bottom: 1rem;
  }
}

@media (max-width: 768px) {
  .container {
    padding: 0 1rem;
  }
  
  .card {
    padding: 1.5rem !important;
  }
  
  .btn {
    padding: 0.6rem 1.2rem;
  }
}

@media (max-width: 576px) {
  .d-flex h3 {
    font-size: 1.5rem;
  }
  
  .form-control, .form-control-static {
    padding: 0.6rem 0.8rem;
  }
}

/* Custom Styling for Price Display */
#total_harga_display, #kembalian_display {
  font-size: 1.1rem;
  background: linear-gradient(to right, #f8f9fa, #e9ecef);
  border-left: 4px solid var(--primary-color);
}

/* Highlight positive kembalian */
#kembalian_display.positive {
  border-left: 4px solid var(--success-color);
}

/* Highlight negative kembalian */
#kembalian_display.negative {
  border-left: 4px solid var(--danger-color);
}

/* Additional JS to add positive/negative classes */
document.addEventListener('DOMContentLoaded', function() {
  const kembalianDisplay = document.getElementById('kembalian_display');
  const kembalianInput = document.getElementById('kembalian');
  
  // Monitor for changes to kembalian value
  if (kembalianInput && kembalianDisplay) {
    const observer = new MutationObserver(function() {
      const value = parseInt(kembalianInput.value) || 0;
      
      // Remove existing classes
      kembalianDisplay.classList.remove('positive', 'negative');
      
      // Add appropriate class
      if (value > 0) {
        kembalianDisplay.classList.add('positive');
      } else if (value < 0) {
        kembalianDisplay.classList.add('negative');
      }
    });
    
    observer.observe(kembalianInput, { attributes: true });
  }
});

/* Form Section Styling */
.mb-3 {
  margin-bottom: 1.5rem !important;
}

/* Field Animation */
.form-control:focus {
  animation: pulse 1s;
}

@keyframes pulse {
  0% { box-shadow: 0 0 0 0 rgba(58, 123, 213, 0.4); }
  70% { box-shadow: 0 0 0 5px rgba(58, 123, 213, 0); }
  100% { box-shadow: 0 0 0 0 rgba(58, 123, 213, 0); }
}

/* Add spacing to buttons */
.d-grid.gap-2 {
  margin-top: 2rem;
}

/* Styles for form sections */
form {
  padding: 0.5rem;
}
    </style>
</head>
<body>

    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3>Tambah Transaksi Baru</h3>
            <a href="transaksi.php" class="btn btn-secondary">Kembali ke Daftar Transaksi</a>
        </div>
        
        <div class="card p-4 mb-5">
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Pilih Pembeli</label>
                    <select name="id_pembeli" class="form-control" required>
                        <?php while ($pembeli = $pembeli_result->fetch_assoc()) { ?>
                            <option value="<?= $pembeli['id_pembeli']; ?>"><?= $pembeli['nama_pembeli']; ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Pilih Produk</label>
                    <select name="id_produk" id="id_produk" class="form-control" required onchange="updateTotal()">
                        <?php while ($produk = $produk_result->fetch_assoc()) { ?>
                            <option value="<?= $produk['id_produk']; ?>" data-harga="<?= $produk['harga_produk']; ?>">
                                <?= $produk['nama_produk']; ?> - Rp <?= number_format($produk['harga_produk'], 0, ',', '.'); ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Pilih Pegawai</label>
                    <select name="id_pegawai" class="form-control" required>
                        <?php while ($pegawai = $pegawai_result->fetch_assoc()) { ?>
                            <option value="<?= $pegawai['id_pegawai']; ?>"><?= $pegawai['nama_pegawai']; ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Total Produk</label>
                    <input type="number" name="total_produk" id="total_produk" class="form-control" required min="1" oninput="updateTotal()">
                </div>
                <div class="mb-3">
                    <label class="form-label">Total Harga</label>
                    <p id="total_harga_display" class="form-control-static">Rp 0</p>
                    <input type="hidden" name="total_harga" id="total_harga">
                </div>
                <div class="mb-3">
                    <label class="form-label">Total Bayar</label>
                    <input type="number" name="total_bayar" id="total_bayar" class="form-control" required oninput="hitungKembalian()">
                </div>
                <div class="mb-3">
                    <label class="form-label">Kembalian</label>
                    <p id="kembalian_display" class="form-control-static">Rp 0</p>
                    <input type="hidden" name="kembalian" id="kembalian">
                </div>
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary">Simpan Transaksi</button>
                    <a href="transaksi.php" class="btn btn-outline-secondary">Batal</a>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>