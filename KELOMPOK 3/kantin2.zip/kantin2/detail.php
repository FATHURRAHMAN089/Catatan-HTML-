<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db = "kantin_sekolah1";
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Periksa apakah id transaksi ada
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: transaksi.php");
    exit;
}

$id_transaksi = $_GET['id'];

// Query untuk mendapatkan detail transaksi
$query = "SELECT t.id_transaksi, t.waktu_beli, p.nama_pembeli, pg.nama_pegawai, 
          t.total_harga, t.total_bayar, t.kembalian 
          FROM transaksi t
          JOIN pembeli p ON t.id_pembeli = p.id_pembeli
          JOIN pegawai_kantin pg ON t.id_pegawai = pg.id_pegawai
          WHERE t.id_transaksi = '$id_transaksi'";

$result = $conn->query($query);

// Periksa apakah transaksi ditemukan
if (!$result || $result->num_rows == 0) {
    echo "Transaksi tidak ditemukan";
    exit;
}

$transaksi = $result->fetch_assoc();

// Query untuk mendapatkan daftar produk dalam transaksi
$query_produk = "SELECT pr.nama_produk, t.total_produk, t.total_harga 
                 FROM transaksi t
                 JOIN produk pr ON t.id_produk = pr.id_produk
                 WHERE t.id_transaksi = '$id_transaksi'";

$result_produk = $conn->query($query_produk);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Detail Transaksi - Kantin Sekolah</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Detail Transaksi #<?= htmlspecialchars($transaksi['id_transaksi']) ?></h4>
                    </div>
                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <h5>Informasi Transaksi</h5>
                                <table class="table table-borderless">
                                    <tr><td>ID Transaksi</td><td>: <?= htmlspecialchars($transaksi['id_transaksi']) ?></td></tr>
                                    <tr><td>Tanggal Transaksi</td><td>: <?= date('d-m-Y H:i', strtotime($transaksi['waktu_beli'])) ?></td></tr>
                                    <tr><td>Nama Pembeli</td><td>: <?= htmlspecialchars($transaksi['nama_pembeli']) ?></td></tr>
                                    <tr><td>Dilayani Oleh</td><td>: <?= htmlspecialchars($transaksi['nama_pegawai']) ?></td></tr>
                                </table>
                            </div>
                            <div class="col-md-6">
                                <h5>Informasi Pembayaran</h5>
                                <table class="table table-borderless">
                                    <tr><td>Total Harga</td><td>: Rp <?= number_format($transaksi['total_harga'], 0, ',', '.') ?></td></tr>
                                    <tr><td>Total Dibayar</td><td>: Rp <?= number_format($transaksi['total_bayar'], 0, ',', '.') ?></td></tr>
                                    <tr><td>Kembalian</td><td>: Rp <?= number_format($transaksi['kembalian'], 0, ',', '.') ?></td></tr>
                                </table>
                            </div>
                        </div>

                        <h5>Detail Produk</h5>
                        <table class="table table-bordered">
                            <thead class="table-light">
                                <tr>
                                    <th>Nama Produk</th>
                                    <th>Jumlah</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($produk = $result_produk->fetch_assoc()) { 
                                    // Hitung harga satuan jika tidak ada kolom 'harga'
                                    $harga_satuan = $produk['total_produk'] > 0 ? ($produk['total_harga'] / $produk['total_produk']) : 0;
                                ?>
                                <tr>
                                    <td><?= htmlspecialchars($produk['nama_produk']) ?></td>
                                    <td><?= htmlspecialchars($produk['total_produk']) ?></td>
                                    <td>Rp <?= number_format($harga_satuan * $produk['total_produk'], 0, ',', '.') ?></td>
                                </tr>
                                <?php } ?>
                            </tbody>
                            <tfoot class="table-light">
                                <tr>
                                    <th colspan="2" class="text-end">Total</th>
                                    <th>Rp <?= number_format($transaksi['total_harga'], 0, ',', '.') ?></th>
                                </tr>
                            </tfoot>
                        </table>

                        <div class="mt-4 text-center">
                            <a href="transaksi.php" class="btn btn-secondary">Kembali ke Daftar Transaksi</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
