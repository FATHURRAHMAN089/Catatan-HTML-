<?php
// koneksi.php - Menghubungkan ke database
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'kantin_sekolah1';

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
