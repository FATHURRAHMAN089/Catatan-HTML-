<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db = "kantin_sekolah1";
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Inisialisasi filter
$filter_day = isset($_GET['day']) ? $_GET['day'] : '';
$filter_month = isset($_GET['month']) ? $_GET['month'] : ''; // Tambahkan filter bulan
$filter_year = isset($_GET['year']) ? $_GET['year'] : '';

// Buat query dasar untuk transaksi
$query = "SELECT t.id_transaksi, b.nama_pembeli, p.nama_produk, pg.nama_pegawai, 
          t.total_produk, t.total_harga, t.waktu_beli
          FROM transaksi t 
          JOIN pembeli b ON t.id_pembeli = b.id_pembeli
          JOIN produk p ON t.id_produk = p.id_produk
          JOIN pegawai_kantin pg ON t.id_pegawai = pg.id_pegawai
          WHERE t.id_produk IS NOT NULL";

// Tambahkan filter berdasarkan hari dalam seminggu
if ($filter_day) {
    // DAYNAME returns the name of the weekday (Monday, Tuesday, etc.)
    // DAYOFWEEK returns numeric day of week (1 = Sunday, 2 = Monday, ..., 7 = Saturday)
    switch ($filter_day) {
        case 'Monday':
            $query .= " AND DAYOFWEEK(waktu_beli) = 2";
            break;
        case 'Tuesday':
            $query .= " AND DAYOFWEEK(waktu_beli) = 3";
            break;
        case 'Wednesday':
            $query .= " AND DAYOFWEEK(waktu_beli) = 4";
            break;
        case 'Thursday':
            $query .= " AND DAYOFWEEK(waktu_beli) = 5";
            break;
        case 'Friday':
            $query .= " AND DAYOFWEEK(waktu_beli) = 6";
            break;
        case 'Saturday':
            $query .= " AND DAYOFWEEK(waktu_beli) = 7";
            break;
        case 'Sunday':
            $query .= " AND DAYOFWEEK(waktu_beli) = 1";
            break;
    }
}

// Filter berdasarkan bulan
if ($filter_month) {
    $query .= " AND MONTH(waktu_beli) = '$filter_month'";
}

// Filter berdasarkan tahun
if ($filter_year) {
    $query .= " AND YEAR(waktu_beli) = '$filter_year'";
}

// Tambahkan order by
$query .= " ORDER BY t.waktu_beli DESC";

// Eksekusi query
$transaksi_result = $conn->query($query);

// Hitung total transaksi dan total pendapatan untuk filter yang dipilih
$total_query = str_replace("SELECT t.id_transaksi, b.nama_pembeli, p.nama_produk, pg.nama_pegawai, 
          t.total_produk, t.total_harga, t.waktu_beli", "SELECT COUNT(*) as total_transaksi, SUM(t.total_harga) as total_pendapatan", $query);
$totals = $conn->query($total_query)->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Transaksi - Kantin Sekolah</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        /* Main Styling for Kantin Sekolah App */
:root {
  --primary-color: #0d6efd;
  --primary-dark: #0a58ca;
  --secondary-color: #f4f7fc;
  --success-color: #28a745;
  --warning-color: #ffc107;
  --danger-color: #dc3545;
  --info-color: #0dcaf0;
  --light-gray: #f8f9fa;
  --dark-gray: #343a40;
  --text-color: #212529;
  --border-radius: 0.375rem;
  --box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
  --transition: all 0.2s ease-in-out;
}

body {
  font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  background-color: #f5f7fa;
  color: var(--text-color);
  line-height: 1.5;
}

/* Container Styling */
.container {
  max-width: 1200px;
  padding: 0 1rem;
}

/* Card Styling */
.card {
  border: none;
  border-radius: var(--border-radius);
  box-shadow: var(--box-shadow);
  transition: var(--transition);
}

.card:hover {
  box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
}

.card-body {
  padding: 1.5rem;
}

.card-title {
  margin-bottom: 1rem;
  font-weight: 600;
  color: var(--dark-gray);
}

/* Table Styling */
.table {
  width: 100%;
  margin-bottom: 1rem;
  vertical-align: middle;
  border-color: #dee2e6;
}

.table-striped tbody tr:nth-of-type(odd) {
  background-color: rgba(0, 0, 0, 0.02);
}

.table-bordered {
  border: 1px solid #dee2e6;
}

.table th, .table td {
  padding: 0.75rem;
  vertical-align: middle;
}

.table-dark {
  background-color: var(--dark-gray);
  color: white;
}

/* Alert Styling */
.alert {
  border: none;
  border-radius: var(--border-radius);
  padding: 1rem;
  margin-bottom: 1rem;
}

.alert-info {
  background-color: rgba(13, 202, 240, 0.15);
  color: #055160;
  border-left: 4px solid var(--info-color);
}

/* Form Styling */
.form-label {
  font-weight: 500;
  margin-bottom: 0.5rem;
  color: var(--dark-gray);
}

.form-control, .form-select {
  border-radius: var(--border-radius);
  padding: 0.375rem 0.75rem;
  border: 1px solid #ced4da;
  transition: var(--transition);
}

.form-control:focus, .form-select:focus {
  box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
  border-color: var(--primary-color);
}

.form-control-static {
  background-color: var(--secondary-color);
  padding: 0.375rem 0.75rem;
  border-radius: var(--border-radius);
  font-weight: 500;
  color: var(--dark-gray);
}

/* Button Styling */
.btn {
  border-radius: var(--border-radius);
  padding: 0.375rem 0.75rem;
  font-weight: 500;
  transition: var(--transition);
}

.btn-primary {
  background-color: var(--primary-color);
  border-color: var(--primary-color);
}

.btn-primary:hover {
  background-color: var(--primary-dark);
  border-color: var(--primary-dark);
  transform: translateY(-1px);
}

.btn-secondary {
  background-color: #6c757d;
  border-color: #6c757d;
}

.btn-secondary:hover {
  background-color: #5c636a;
  border-color: #565e64;
  transform: translateY(-1px);
}

.btn-info {
  background-color: var(--info-color);
  border-color: var(--info-color);
  color: #000;
}

.btn-info:hover {
  background-color: #31d2f2;
  border-color: #25cff2;
  transform: translateY(-1px);
}

.btn-warning {
  background-color: var(--warning-color);
  border-color: var(--warning-color);
  color: #000;
}

.btn-warning:hover {
  background-color: #ffca2c;
  border-color: #ffc720;
  transform: translateY(-1px);
}

.btn-danger {
  background-color: var(--danger-color);
  border-color: var(--danger-color);
}

.btn-danger:hover {
  background-color: #bb2d3b;
  border-color: #b02a37;
  transform: translateY(-1px);
}

.btn-sm {
  padding: 0.25rem 0.5rem;
  font-size: 0.875rem;
  border-radius: 0.25rem;
}

/* Header Styling */
.d-flex.justify-content-between.align-items-center {
  margin-bottom: 1.5rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid rgba(0, 0, 0, 0.1);
}

.d-flex h3 {
  font-weight: 600;
  color: var(--dark-gray);
  margin-bottom: 0;
}

/* Filter Form */
.row.g-3 {
  margin-bottom: 0;
}

/* Custom Price Display */
#total_harga_display, #kembalian_display {
  background-color: var(--light-gray);
  border-left: 4px solid var(--primary-color);
  margin-bottom: 0;
}

/* Responsive Styles */
@media (max-width: 992px) {
  .d-flex.justify-content-between.align-items-center {
    flex-direction: column;
    align-items: flex-start !important;
  }
  
  .d-flex h3 {
    margin-bottom: 1rem;
  }
  
  .row.g-3 > div {
    margin-bottom: 1rem;
  }
}

@media (max-width: 768px) {
  .table thead {
    display: none;
  }
  
  .table, .table tbody, .table tr, .table td {
    display: block;
    width: 100%;
  }
  
  .table tr {
    margin-bottom: 1rem;
    border: 1px solid #dee2e6;
    border-radius: var(--border-radius);
    overflow: hidden;
  }
  
  .table td {
    position: relative;
    padding-left: 50%;
    text-align: right;
    border-bottom: 1px solid #dee2e6;
  }
  
  .table td:before {
    content: attr(data-label);
    position: absolute;
    left: 0.75rem;
    width: 45%;
    padding-right: 0.75rem;
    text-align: left;
    font-weight: 600;
  }
  
  .table td:last-child {
    border-bottom: 0;
  }
  
  .table-bordered td {
    border: none;
    border-bottom: 1px solid #dee2e6;
  }
}

@media (max-width: 576px) {
  .card-body {
    padding: 1rem;
  }
  
  .btn {
    padding: 0.25rem 0.5rem;
  }
  
  .alert {
    padding: 0.75rem;
  }
}

/* Custom Script for Mobile Table Data Labels */
document.addEventListener('DOMContentLoaded', function() {
  if (window.innerWidth <= 768) {
    const tableHeaderCells = document.querySelectorAll('table thead th');
    const tableBodyRows = document.querySelectorAll('table tbody tr');
    
    tableBodyRows.forEach(row => {
      const cells = row.querySelectorAll('td');
      cells.forEach((cell, index) => {
        if (tableHeaderCells[index]) {
          cell.setAttribute('data-label', tableHeaderCells[index].textContent);
        }
      });
    });
  }
});

/* Highlighting for Form Fields */
.form-control:focus, .form-select:focus {
  animation: highlight 2s;
}

@keyframes highlight {
  0% { box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25); }
  70% { box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25); }
  100% { box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0); }
}

/* Responsive Button Adjustments */
@media (max-width: 576px) {
  td .btn {
    display: inline-block;
    margin-bottom: 0.25rem;
    width: 100%;
  }
}
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Kantin Sekolah</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="produk.php">Produk</a></li>
                    <li class="nav-item"><a class="nav-link active" href="transaksi.php">Transaksi</a></li>
                    <li class="nav-item"><a class="nav-link" href="pembeli.php">Pembeli</a></li>
                    <li class="nav-item"><a class="nav-link" href="pegawai.php">Pegawai</a></li>
                    <li class="nav-item"><a class="btn btn-danger" href="login.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3>Daftar Transaksi</h3>
            <a href="tambah_transaksi.php" class="btn btn-primary">
                <i class="bi bi-plus-circle"></i> Tambah Transaksi Baru
            </a>
        </div>
        
        <!-- Filter Form -->
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">Filter Transaksi</h5>
                <form method="GET" class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">Hari</label>
                        <select name="day" class="form-select">
                            <option value="">Semua Hari</option>
                            <option value="Monday" <?= $filter_day == 'Monday' ? 'selected' : '' ?>>Senin</option>
                            <option value="Tuesday" <?= $filter_day == 'Tuesday' ? 'selected' : '' ?>>Selasa</option>
                            <option value="Wednesday" <?= $filter_day == 'Wednesday' ? 'selected' : '' ?>>Rabu</option>
                            <option value="Thursday" <?= $filter_day == 'Thursday' ? 'selected' : '' ?>>Kamis</option>
                            <option value="Friday" <?= $filter_day == 'Friday' ? 'selected' : '' ?>>Jumat</option>
                            <option value="Saturday" <?= $filter_day == 'Saturday' ? 'selected' : '' ?>>Sabtu</option>
                            <option value="Sunday" <?= $filter_day == 'Sunday' ? 'selected' : '' ?>>Minggu</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Bulan</label>
                        <select name="month" class="form-select">
                            <option value="">Semua Bulan</option>
                            <option value="1" <?= $filter_month == '1' ? 'selected' : '' ?>>Januari</option>
                            <option value="2" <?= $filter_month == '2' ? 'selected' : '' ?>>Februari</option>
                            <option value="3" <?= $filter_month == '3' ? 'selected' : '' ?>>Maret</option>
                            <option value="4" <?= $filter_month == '4' ? 'selected' : '' ?>>April</option>
                            <option value="5" <?= $filter_month == '5' ? 'selected' : '' ?>>Mei</option>
                            <option value="6" <?= $filter_month == '6' ? 'selected' : '' ?>>Juni</option>
                            <option value="7" <?= $filter_month == '7' ? 'selected' : '' ?>>Juli</option>
                            <option value="8" <?= $filter_month == '8' ? 'selected' : '' ?>>Agustus</option>
                            <option value="9" <?= $filter_month == '9' ? 'selected' : '' ?>>September</option>
                            <option value="10" <?= $filter_month == '10' ? 'selected' : '' ?>>Oktober</option>
                            <option value="11" <?= $filter_month == '11' ? 'selected' : '' ?>>November</option>
                            <option value="12" <?= $filter_month == '12' ? 'selected' : '' ?>>Desember</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Tahun</label>
                        <input type="number" name="year" class="form-control" value="<?= $filter_year ?>">
                    </div>
                    <div class="col-md-3 d-flex align-items-end">
                        <div>
                            <button type="submit" class="btn btn-primary">Filter</button>
                            <a href="transaksi.php" class="btn btn-secondary">Reset</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Ringkasan Transaksi -->
        <?php if ($filter_day || $filter_month || $filter_year): ?>
        <div class="alert alert-info">
            <h5>Ringkasan Transaksi</h5>
            <p>
                Total Transaksi: <strong><?= $totals['total_transaksi'] ?></strong><br>
                Total Pendapatan: <strong>Rp <?= number_format($totals['total_pendapatan'], 0, ',', '.') ?></strong>
            </p>
        </div>
        <?php endif; ?>

        <table class="table table-striped table-bordered">
            <thead class="table-dark">
                <tr>
                    <th>No</th>
                    <th>Nama Pembeli</th>
                    <th>Nama Produk</th>
                    <th>Jumlah Produk</th>
                    <th>Total Harga</th>
                    <th>Tanggal Transaksi</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $no = 1; 
                if ($transaksi_result->num_rows > 0) {
                    while ($row = $transaksi_result->fetch_assoc()) { 
                ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td><?= $row['nama_pembeli']; ?></td>
                        <td><?= $row['nama_produk']; ?></td>
                        <td><?= $row['total_produk']; ?></td>
                        <td>Rp <?= number_format($row['total_harga'], 0, ',', '.'); ?></td>
                        <td><?= date('d F Y H:i', strtotime($row['waktu_beli'])); ?></td>
                        <td>
                            <a href="edit_transaksi.php?id=<?= $row['id_transaksi']; ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="delete_transaksi.php?id=<?= $row['id_transaksi']; ?>" class="btn btn-danger btn-sm">Delete</a>
                            <a href="detail.php?id=<?= $row['id_transaksi']; ?>" class="btn btn-info btn-sm">Detail</a>
                        </td>
                    </tr>
                <?php 
                    }
                } else {
                ?>
                    <tr>
                        <td colspan="7" class="text-center">Tidak ada data transaksi</td>
                    </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
</body>
</html>