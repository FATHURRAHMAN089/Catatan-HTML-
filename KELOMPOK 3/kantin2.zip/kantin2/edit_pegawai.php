<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db = "kantin_sekolah1";
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$id_pegawai = $_GET['id'];
$pegawai = $conn->query("SELECT * FROM pegawai_kantin WHERE id_pegawai = '$id_pegawai'")->fetch_assoc();

// Update Pegawai
if (isset($_POST['update'])) {
    $nama_pegawai = $_POST['nama_pegawai'];

    $query = "UPDATE pegawai_kantin SET nama_pegawai='$nama_pegawai' WHERE id_pegawai='$id_pegawai'";
    $conn->query($query);
    header("Location: pegawai_kantin.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Pegawai</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
    <h3>Edit Pegawai</h3>
    <div class="card p-4">
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Nama Pegawai</label>
                <input type="text" name="nama_pegawai" class="form-control" required value="<?= $pegawai['nama_pegawai']; ?>">
            </div>
            <button type="submit" name="update" class="btn btn-primary w-100">Simpan Perubahan</button>
            <a href="pegawai.php" class="btn btn-secondary w-100 mt-2">Batal</a>
        </form>
    </div>
</div>
</body>
</html>
