<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db = "kantin_sekolah1";
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil ID Pegawai
$id_pegawai = isset($_GET['id']) ? $_GET['id'] : 0;

// Ambil Data Pegawai
$pegawai_query = $conn->query("SELECT nama_pegawai FROM pegawai_kantin WHERE id_pegawai = '$id_pegawai'");
$pegawai = $pegawai_query->fetch_assoc();

// Ambil Total Pendapatan Pegawai dari Transaksi
$pendapatan_query = $conn->query("SELECT SUM(total_harga) AS total_pendapatan FROM transaksi WHERE id_pegawai = '$id_pegawai'");
$pendapatan = $pendapatan_query->fetch_assoc();
$total_pendapatan = $pendapatan['total_pendapatan'] ?? 0;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Record Pendapatan Pegawai</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-4">
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0">Record Pendapatan Pegawai</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <h5>Nama Pegawai</h5>
                    <p><?= $pegawai['nama_pegawai']; ?></p>
                </div>
                <div class="col-md-6">
                    <h5>Total Pendapatan</h5>
                    <p>Rp <?= number_format($total_pendapatan, 0, ',', '.'); ?></p>
                </div>
            </div>
        </div>
        <div class="card-footer text-end">
            <a href="pegawai.php" class="btn btn-secondary">Kembali</a>
            <button onclick="window.print()" class="btn btn-success">Cetak</button>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
