<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db = "kantin_sekolah";
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if (isset($_POST['tambah'])) {
    $nama_pembeli = $_POST['nama_pembeli'];
    $sql = "INSERT INTO pembeli (nama_pembeli) VALUES ('$nama_pembeli')";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Pembeli berhasil ditambahkan!'); window.location.href='dashboard_pembeli.php';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan pembeli!');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Pembeli</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-4">
    <h3>Tambah Pembeli</h3>
    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Nama Pembeli</label>
            <input type="text" name="nama_pembeli" class="form-control" required>
        </div>
        <button type="submit" name="tambah" class="btn btn-primary">Tambah Pembeli</button>
        <a href="dashboard_pembeli.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>

</body>
</html>
