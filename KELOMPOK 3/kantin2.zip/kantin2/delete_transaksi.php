<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db = "kantin_sekolah1";
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Cek apakah ada ID transaksi yang dikirim
if (isset($_GET['id'])) {
    $id_transaksi = $_GET['id'];

    // Hapus transaksi berdasarkan ID
    $query = "DELETE FROM transaksi WHERE id_transaksi = '$id_transaksi'";

    if ($conn->query($query) === TRUE) {
        header("Location: transaksi.php"); // Redirect ke halaman transaksi
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
} else {
    echo "ID Transaksi tidak ditemukan.";
}

$conn->close();
?>
