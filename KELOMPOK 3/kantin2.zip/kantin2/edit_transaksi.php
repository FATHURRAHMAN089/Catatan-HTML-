<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db = "kantin_sekolah1";
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data transaksi berdasarkan ID
$id_transaksi = $_GET['id'] ?? '';
$transaksi_query = $conn->query("SELECT * FROM transaksi WHERE id_transaksi = '$id_transaksi'");
$transaksi = $transaksi_query->fetch_assoc();

// Ambil data produk, pembeli, dan pegawai
$produk_result = $conn->query("SELECT * FROM produk");
$pembeli_result = $conn->query("SELECT * FROM pembeli");
$pegawai_result = $conn->query("SELECT * FROM pegawai_kantin");

// Update transaksi
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_pembeli = $_POST['id_pembeli'];
    $id_produk = $_POST['id_produk'];
    $id_pegawai = $_POST['id_pegawai'];
    $total_produk = $_POST['total_produk'];
    $total_bayar = $_POST['total_bayar'];
    $waktu_beli = date('Y-m-d H:i:s');

    // Ambil harga produk dari database
    $total_query = $conn->query("SELECT harga_produk FROM produk WHERE id_produk = '$id_produk'");
    $total_result = $total_query->fetch_assoc();
    $harga_produk = $total_result['harga_produk'];

    // Hitung total harga
    $total_harga = $harga_produk * $total_produk;

    // Hitung kembalian
    $kembalian = $total_bayar - $total_harga;

    // Update transaksi di database
    $query = "UPDATE transaksi SET id_pembeli='$id_pembeli', id_produk='$id_produk', id_pegawai='$id_pegawai', total_produk='$total_produk', total_harga='$total_harga', total_bayar='$total_bayar', kembalian='$kembalian' WHERE id_transaksi='$id_transaksi'";

    if ($conn->query($query) === TRUE) {
        header("Location: transaksi.php");
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Transaksi</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script>
        function hitungTotal() {
            var harga_produk = parseInt(document.getElementById("id_produk").selectedOptions[0].dataset.harga);
            var total_produk = parseInt(document.getElementById("total_produk").value);
            var total_bayar = parseInt(document.getElementById("total_bayar").value);

            if (isNaN(harga_produk) || isNaN(total_produk)) {
                harga_produk = 0;
                total_produk = 0;
            }

            var total_harga = harga_produk * total_produk;
            document.getElementById("total_harga").value = total_harga;

            var kembalian = total_bayar - total_harga;
            document.getElementById("kembalian").value = kembalian;
        }
    </script>
</head>
<body>
<div class="container mt-4">
    <h3>Edit Transaksi</h3>
    <div class="card p-4">
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Pilih Pembeli</label>
                <select name="id_pembeli" class="form-control" required>
                    <?php while ($pembeli = $pembeli_result->fetch_assoc()) { ?>
                        <option value="<?= $pembeli['id_pembeli']; ?>" <?= ($transaksi['id_pembeli'] == $pembeli['id_pembeli']) ? 'selected' : ''; ?>>
                            <?= $pembeli['nama_pembeli']; ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Pilih Produk</label>
                <select name="id_produk" id="id_produk" class="form-control" required onchange="hitungTotal()">
                    <?php while ($produk = $produk_result->fetch_assoc()) { ?>
                        <option value="<?= $produk['id_produk']; ?>" data-harga="<?= $produk['harga_produk']; ?>" <?= ($transaksi['id_produk'] == $produk['id_produk']) ? 'selected' : ''; ?>>
                            <?= $produk['nama_produk']; ?> - Rp <?= number_format($produk['harga_produk'], 0, ',', '.'); ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Pilih Pegawai</label>
                <select name="id_pegawai" class="form-control" required>
                    <?php while ($pegawai = $pegawai_result->fetch_assoc()) { ?>
                        <option value="<?= $pegawai['id_pegawai']; ?>" <?= ($transaksi['id_pegawai'] == $pegawai['id_pegawai']) ? 'selected' : ''; ?>>
                            <?= $pegawai['nama_pegawai']; ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Total Produk</label>
                <input type="number" name="total_produk" id="total_produk" class="form-control" required min="1" value="<?= $transaksi['total_produk']; ?>" oninput="hitungTotal()">
            </div>
            <div class="mb-3">
                <label class="form-label">Total Harga</label>
                <input type="number" id="total_harga" class="form-control" value="<?= $transaksi['total_produk'] * ($transaksi_query->fetch_assoc()['total_harga'] ?? 0); ?>" readonly>
            </div>
            <div class="mb-3">
                <label class="form-label">Total Bayar</label>
                <input type="number" name="total_bayar" id="total_bayar" class="form-control" required value="<?= $transaksi['total_bayar']; ?>" oninput="hitungTotal()">
            </div>
            <div class="mb-3">
                <label class="form-label">Total Kembalian</label>
                <input type="number" id="kembalian" class="form-control" value="<?= $transaksi['kembalian']; ?>" readonly>
            </div>
            <button type="submit" class="btn btn-primary w-100 mb-2">Simpan Perubahan</button>
            <a href="transaksi.php" class="btn btn-secondary w-100">Kembali</a>
        </form>
    </div>
</div>
</body>
</html>
