<?php
// koneksi.php - Menghubungkan ke database
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'kantin_sekolah1';

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

session_start();

// Mengecek apakah user sudah login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Ambil data jumlah produk
$produk_result = $conn->query("SELECT COUNT(*) as total_produk FROM produk");
$produk_data = $produk_result->fetch_assoc();
$total_produk = $produk_data['total_produk'];

// Ambil data jumlah transaksi
$transaksi_result = $conn->query("SELECT COUNT(*) as total_transaksi FROM transaksi");
$transaksi_data = $transaksi_result->fetch_assoc();
$total_transaksi = $transaksi_data['total_transaksi'];

// Ambil data total pendapatan
$pendapatan_result = $conn->query("SELECT SUM(total_harga) as total_pendapatan FROM transaksi");
$pendapatan_data = $pendapatan_result->fetch_assoc();
$total_pendapatan = $pendapatan_data['total_pendapatan'] ?? 0;

// Ambil data jumlah pembeli
$pembeli_result = $conn->query("SELECT COUNT(*) as total_pembeli FROM pembeli");
$pembeli_data = $pembeli_result->fetch_assoc();
$total_pembeli = $pembeli_data['total_pembeli'];

// Ambil data jumlah pegawai
$pegawai_result = $conn->query("SELECT COUNT(*) as total_pegawai FROM pegawai_kantin");
$pegawai_data = $pegawai_result->fetch_assoc();
$total_pegawai = $pegawai_data['total_pegawai'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Kantin Sekolah</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }
        .navbar {
            background-color: #343a40 !important;
        }
        .navbar-brand, .nav-link {
            color: white !important;
        }
        .card {
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Kantin Sekolah</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="produk.php">Produk</a></li>
                    <li class="nav-item"><a class="nav-link" href="transaksi.php">Transaksi</a></li>
                    <li class="nav-item"><a class="nav-link" href="pembeli.php">Pembeli</a></li>
                    <li class="nav-item"><a class="nav-link" href="pegawai.php">Pegawai</a></li>
                    <li class="nav-item"><a class="btn btn-danger" href="login.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <h3 class="text-center mb-4">Dashboard Kantin Sekolah</h3>
        <div class="row">
            <div class="col-md-4">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <h5 class="card-title">Total Produk</h5>
                        <p class="card-text">Jumlah: <?= $total_produk; ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <h5 class="card-title">Total Transaksi</h5>
                        <p class="card-text">Jumlah: <?= $total_transaksi; ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-warning text-white">
                    <div class="card-body">
                        <h5 class="card-title">Total Pendapatan</h5>
                        <p class="card-text">Rp <?= number_format($total_pendapatan, 0, ',', '.'); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-6">
                <canvas id="grafikPembeli"></canvas>
            </div>
            <div class="col-md-6">
                <canvas id="grafikPegawai"></canvas>
            </div>
        </div>
    </div>

    <script>
        const ctxPembeli = document.getElementById('grafikPembeli').getContext('2d');
        const ctxPegawai = document.getElementById('grafikPegawai').getContext('2d');

        // Data Pembeli
        new Chart(ctxPembeli, {
            type: 'bar',
            data: {
                labels: ['Total Pembeli'],
                datasets: [{
                    label: 'Jumlah Pembeli',
                    data: [<?= $total_pembeli; ?>],
                    backgroundColor: 'rgba(75, 192, 192, 0.5)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Data Pegawai
        new Chart(ctxPegawai, {
            type: 'bar',
            data: {
                labels: ['Total Pegawai'],
                datasets: [{
                    label: 'Jumlah Pegawai',
                    data: [<?= $total_pegawai; ?>],
                    backgroundColor: 'rgba(255, 99, 132, 0.5)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>