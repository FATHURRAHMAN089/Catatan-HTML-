# Website absensi Siswa Per Pekan

# Web ini dibuat menggunakan
- XAMPP minimal versi PHP 5 keatas
- Visual Studio Code (VSC)
- Google Chrome
- PHP
- HTML
 - CSS
- Bootstrap

# Cara Menggunakan 
- install xampp minimal versi PHP5 ke atas
- Lalu import database yang terletak pada folder project
- sesuaikan nama koneksi.php dengan databasenya contonya seperti ini `$koneksi = mysqli_connect('localhost', 'root', '', 'absen_perpekan') or die ('koneksi gagal');`.
- lalu pindahkan file yang ada di proyek ke folder htdocs.
- jalankan apache dan mysql pada xampp.
- lalu akses pada browser dengan url `localhost/namafoldernya/file.`
- contoh cara mengakses di browser `http://localhost/proyek/login.php`.

# Username  & Password

## Admin
- `Username = Admin`
- `Password = admin123`
## Ketua Kelas
- `Username = rey`
- `Password = 123`

